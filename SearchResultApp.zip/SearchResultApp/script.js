const app = document.getElementById('root');
const container = document.createElement('div');
container.setAttribute('class', 'searchResultApp');
app.appendChild(container);
const searchResultPage1 = undefined;
const searchResultPage = document.createElement('div')
searchResultPage.setAttribute('class', 'searchResultPage');
//dropdown
function dropDownContainer() {
    const sortByDropdown = document.createElement('div');
    sortByDropdown.setAttribute('class', 'sortByDropdown');
    sortByDropdown.innerHTML = `<div class="dropdown"><button class="dropbtn">Sort by</button> <div class="dropdown-content">
    <a href="#" value="Lowest price first" onClick = sortResults(this)>Lowest price first</a>
    <a href="#" value="Highest price first" onClick = sortResults(this)>Highest price first</a>
    <a href="#" value="Longest tour first" onClick = sortResultBydistance(this)>Longest tour first</a> 
    <a href="#" value="Shortest tour first" onClick = sortResultBydistance(this)>Shortest tour first</a> </div> </div>`
    //filter

    const filterByDropdown = document.createElement('div');
    filterByDropdown.setAttribute('class', 'filterByDropdown');
    filterByDropdown.innerHTML = `<div class="dropdown">
    <button class="dropbtn">Filter by</button>
    <div class="dropdown-content">
    <a href="#" value="none" onClick = filterResults(this)>No Filter</a>
    <a href="#" value="Mar 2017" onClick = filterResults(this)>Mar 2017</a>
    <a href="#" value="Apr 2017" onClick = filterResults(this)>Apr 2017</a>
    <a href="#" value="May 2017" onClick = filterResults(this)>May 2017</a>
    <a href="#" value="Jun 2017" onClick = filterResults(this)>Jun 2017</a>
    </div>
    </div>
    </div>`
    const dropDownContainer = document.createElement('div')
    dropDownContainer.setAttribute('class', 'dropDownContainer');

    dropDownContainer.appendChild(sortByDropdown);
    dropDownContainer.appendChild(filterByDropdown);
    searchResultPage.appendChild(dropDownContainer);
    container.appendChild(searchResultPage);
}

let eachtripDestination = undefined;
let sortedStartingDatesForAllResults = []
let sortedResultsBasedOnSortCriterion = []
let sortedStartingDates = undefined;
let request = new XMLHttpRequest();
let data = []
let sortResultValue = undefined;
request.open('GET', 'https://api.myjson.com/bins/6iv3y', true);
request.onload = function () {

    // Begin accessing JSON data here
    data = JSON.parse(this.response);
    if (request.status >= 200 && request.status < 400) {
        dropDownContainer()
        data.forEach((eachSearchResultEntry, index) => {
            // component start
            imageComponent(eachSearchResultEntry);
            leftDestinationInfoComponent(eachSearchResultEntry);
            rightDestinationInfoComponent(eachSearchResultEntry, index);
            // component end
        });
    } else {
        const errorMessage = document.createElement('marquee');
        errorMessage.textContent = `Gah, it's not working!`;
        app.appendChild(errorMessage);
    }
}

request.send();

const sortResultBydistance = (link) => {
    let distanceArray = [];
    $('.searchResultPage').empty();
    dropDownContainer()
    data.forEach(function (eachSearchResultEntry, index) {
        let sortedCities = eachSearchResultEntry.cities && eachSearchResultEntry.cities.sort((city1, city2) => {
            return city1.lng - city2.lng
        })

        dlon = sortedCities[1].lng - sortedCities[0].lng
        dlat = sortedCities[1].lat - sortedCities[0].lat
        a = (Math.sin(dlat / 2)) ^ 2 + Math.cos(sortedCities[0].lat) * Math.cos(sortedCities[1].lat) * (Math.sin(dlon / 2)) ^ 2
        c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
        distanceArray[index] = { key: c, value: eachSearchResultEntry };

    });
    if (link.getAttribute('value') !== 'Shortest tour first') {
        distanceArray.sort((distance1, distance2) => {
            return distance1.key - distance2.key
        }).forEach((disatnce, index) => {
            imageComponent(disatnce.value);
            leftDestinationInfoComponent(disatnce.value);
            rightDestinationInfoComponent(disatnce.value, index);
        })
    }
    if (link.getAttribute('value') !== 'Longest tour first') {
        distanceArray.sort((distance1, distance2) => {
            return distance2.key - distance1.key
        }).forEach((disatnce, index) => {
            imageComponent(disatnce.value);
            leftDestinationInfoComponent(disatnce.value);
            rightDestinationInfoComponent(disatnce.value, index);
        })
    }
}

const filterResults = (link) => {
    if (link.getAttribute('value') !== 'none') {
        $('.searchResultPage').empty();
        let filterFlag = false;
        dropDownContainer()
        data.forEach(function (eachSearchResultEntry, index) {
            filterFlag = false;
            eachSearchResultEntry.dates && eachSearchResultEntry.dates.forEach(function (date) {

                if (formatDate(date.start !== undefined && date.start)
                    .slice(formatDate(date.start !== undefined && date.start).
                        indexOf(' ')) === ' ' + link.getAttribute('value') && filterFlag === false) {

                    imageComponent(eachSearchResultEntry);
                    leftDestinationInfoComponent(eachSearchResultEntry);
                    rightDestinationInfoComponent(eachSearchResultEntry, index);
                    filterFlag = true;
                }
            });
        });
    }
    if (link.getAttribute('value') === 'none') {
        $('.searchResultPage').empty();
        dropDownContainer()
        data.forEach(function (eachSearchResultEntry, index) {
            imageComponent(eachSearchResultEntry);
            leftDestinationInfoComponent(eachSearchResultEntry);
            rightDestinationInfoComponent(eachSearchResultEntry, index);
        });
    }
}

const sortResults = (link) => {
    sortResultValue = link.getAttribute('value');
    let i, switching, b, shouldSwitch;
    list = document.getElementsByClassName("searchResultPage");
    switching = true;
    while (switching) {
        switching = false;
        b = document.getElementsByClassName("eachtripDestination");

        for (i = 0; i < (b.length - 1); i++) {
            shouldSwitch = false;
            if (link.getAttribute('value') === 'Lowest price first') {
                if (Number(b[i].getElementsByClassName("finalPrice")[0].innerText) > Number(b[i + 1].getElementsByClassName("finalPrice")[0].innerText)) {
                    shouldSwitch = true;
                    break;
                }
            }
            if (link.getAttribute('value') === 'Highest price first') {
                if (Number(b[i].getElementsByClassName("finalPrice")[0].innerText) < Number(b[i + 1].getElementsByClassName("finalPrice")[0].innerText)) {
                    shouldSwitch = true;
                    break;
                }
            }
        }
        if (shouldSwitch) {
            b[i].parentNode.insertBefore(b[i + 1], b[i]);
            switching = true;
        }
    }
}

const getPrimaryImage = (eachSearchResultEntry) => {
    let filteredPromaryImage = eachSearchResultEntry.images && eachSearchResultEntry.images.filter(image => image.is_primary === true)
    return filteredPromaryImage.length > 0 ? filteredPromaryImage[0].url : eachSearchResultEntry.images.length > 0 && eachSearchResultEntry.images[0].url
}
const getStartEnds = (eachSearchResultEntry) => {
    let sortedCities = eachSearchResultEntry.cities && eachSearchResultEntry.cities.sort((city1, city2) => {
        return city1.lng - city2.lng
    })
    return sortedCities[0].name + ' / ' + sortedCities[1].name
}

function formatDate(d) {
    var monthNames = [
        "Jan", "Feb", "Mar",
        "Apr", "May", "Jun", "Jul",
        "Aug", "Sep", "Oct",
        "Nov", "Dec"
    ];
    var date = new Date(d);
    var day = date.getDate();
    var monthIndex = date.getMonth();
    var year = date.getFullYear();

    return day + ' ' + monthNames[monthIndex] + ' ' + year;
}

const getSTartingPriceAndDiscount = (eachSearchResultEntry, index) => {
    let sortedStartingPrice = eachSearchResultEntry.dates.filter(date => date.availability > 0).sort((price1, price2) => {
        return price1.eur - price2.eur
    })
    let maxDiscountArray = eachSearchResultEntry.dates.filter(date => date.availability > 0).filter(date => date.discount && Number(date.discount.slice(0, -1)) > 0).sort((price1, price2) => {
        return Number(price2.discount.slice(0, -1)) - Number(price1.discount.slice(0, -1))

    })
    sortedStartingPrice.length > 0 ? sortedResultsBasedOnSortCriterion[index] = { key: sortedStartingPrice[0].eur, eachSearchResultEntry } : ''

    return `${sortedStartingPrice.length > 0 ? '<div class="startFromLabel">From</div> €' : '<span class="noPrice">Price Not Available</span>'} <span class="finalPrice">${sortedStartingPrice.length > 0 ? sortedStartingPrice[0].eur : ''}  </span>
    <div class="priceDiscount"> ${ maxDiscountArray.length > 0 && maxDiscountArray[0].discount ? `<strike>€ ${Math.round(sortedStartingPrice[0].eur * 100 / Number(100 - maxDiscountArray[0].discount.slice(0, -1)))}</strike> <span class="discountValue">${maxDiscountArray[0].discount} off</span>` : ''}</div> `
}

const getDatesAndVacentSpacesAvailable = (eachSearchResultEntry, index) => {
    sortedStartingDates = eachSearchResultEntry.dates.filter(date => date.availability > 0).sort((date1, date2) => {
        return new Date(date1.start) - new Date(date2.start)
    })
    sortedStartingDatesForAllResults[index] = { key: sortedStartingDates[0] !== undefined && sortedStartingDates[0].start, eachSearchResultEntry }
    return sortedStartingDates.length > 0 ? `<div class="startsFromContainer"><div class="startFrom">${formatDate(sortedStartingDates[0].start)} <span class="onlyLeft">${sortedStartingDates[0].availability < 10 ? 'only ' + sortedStartingDates[0].availability + ' left' : ' ' + 10 + '+ left'}</span></div> <div class="startFrom">${formatDate(sortedStartingDates[1].start)}<span class="onlyLeft">${sortedStartingDates[1].availability < 10 ? ' only ' + sortedStartingDates[1].availability + ' left' : ' ' + 10 + '+ left'}</span></div></div>` : '<span class="notAvailable">Not Available</span>'

}

const getStars = (rating) => {
    rating = Math.round(rating * 2) / 2;
    let output = [];

    for (var i = rating; i >= 1; i--)
        output.push('<i class="fa fa-star" aria-hidden="true" style="color: orange;"></i>&nbsp;');

    if (i == .5) output.push('<i class="fa fa-star-half-o" aria-hidden="true" style="color: orange;"></i>&nbsp;');

    for (let i = (5 - rating); i >= 1; i--)
        output.push('<i class="fa fa-star-o" aria-hidden="true" style="color: orange;"></i>&nbsp;');

    return output.join('');

}

const imageComponent = (eachSearchResultEntry) => {
    eachtripDestination = document.createElement('div');
    eachtripDestination.setAttribute('class', 'eachtripDestination');
    const eachtripDestinationImage = document.createElement('div');
    eachtripDestinationImage.setAttribute('class', 'eachtripDestinationImage');
    const destinationImage = document.createElement('img');
    destinationImage.setAttribute('class', 'destinationImage');
    destinationImage.setAttribute('src', getPrimaryImage(eachSearchResultEntry));
    destinationImage.setAttribute('alt', 'destination pic');
    const heartImage = document.createElement('div');
    heartImage.setAttribute('class', 'heartImage');
    heartImage.innerHTML = `<div class="heart"></div>`
    searchResultPage.appendChild(eachtripDestination);
    eachtripDestination.appendChild(eachtripDestinationImage);
    eachtripDestinationImage.appendChild(heartImage);
    eachtripDestinationImage.appendChild(destinationImage);

}

const leftDestinationInfoComponent = (eachSearchResultEntry) => {
    const leftDestinationInfo = document.createElement('div');
    leftDestinationInfo.setAttribute('class', 'leftDestinationInfo');
    //destinationname
    const destinationName = document.createElement('div');
    destinationName.setAttribute('class', 'destinationName');
    destinationName.textContent = eachSearchResultEntry.name;
    //rating and reviews
    const ratingAndReviews = document.createElement('div');
    ratingAndReviews.setAttribute('class', 'ratingAndReviews');
    const rating = document.createElement('div');
    rating.setAttribute('class', 'rating');
    rating.innerHTML = getStars(eachSearchResultEntry.rating);
    const reviews = document.createElement('div');
    reviews.setAttribute('class', 'reviews');
    reviews.textContent = eachSearchResultEntry.reviews + ' reviews'
    //description
    const description = document.createElement('div');
    description.setAttribute('class', 'description');
    description.textContent = eachSearchResultEntry.description

    //start end block with destination
    const destinationStartEOperator = document.createElement('div');
    destinationStartEOperator.setAttribute('class', 'destinationStartEOperator');
    const destination = document.createElement('div');
    destination.setAttribute('class', 'destination');
    const destinationLabel = document.createElement('div');
    destinationLabel.setAttribute('class', 'textLabel');
    destinationLabel.textContent = 'DESTINATIONS'
    const destinationValue = document.createElement('div');
    destinationValue.setAttribute('class', 'textValue');
    destinationValue.textContent = eachSearchResultEntry.cities && eachSearchResultEntry.cities.length + ' destinations';

    const startEnd = document.createElement('div');
    startEnd.setAttribute('class', 'startEnd');
    const startEndLabel = document.createElement('div');
    startEndLabel.setAttribute('class', 'textLabel');
    startEndLabel.textContent = 'STARTS/ENDS IN'
    const startEndValue = document.createElement('div');
    startEndValue.setAttribute('class', 'textValue');
    startEndValue.textContent = getStartEnds(eachSearchResultEntry)

    const operator = document.createElement('div');
    operator.setAttribute('class', 'operator');
    const operatorLabel = document.createElement('div');
    operatorLabel.setAttribute('class', 'textLabel');
    operatorLabel.textContent = 'OPERATOR'
    const operatorValue = document.createElement('div');
    operatorValue.setAttribute('class', 'textValue');
    operatorValue.textContent = eachSearchResultEntry.operator_name

    eachtripDestination.appendChild(leftDestinationInfo);
    leftDestinationInfo.appendChild(destinationName);
    leftDestinationInfo.appendChild(ratingAndReviews);
    ratingAndReviews.appendChild(rating);
    ratingAndReviews.appendChild(reviews);
    leftDestinationInfo.appendChild(description);
    leftDestinationInfo.appendChild(destinationStartEOperator);
    destinationStartEOperator.appendChild(destination);
    destination.appendChild(destinationLabel);
    destination.appendChild(destinationValue);
    destinationStartEOperator.appendChild(startEnd);
    startEnd.appendChild(startEndLabel);
    startEnd.appendChild(startEndValue);
    destinationStartEOperator.appendChild(operator);
    operator.appendChild(operatorLabel);
    operator.appendChild(operatorValue);


}

const rightDestinationInfoComponent = (eachSearchResultEntry, index) => {

    const rightDestinationInfo = document.createElement('div');
    rightDestinationInfo.setAttribute('class', 'rightDestinationInfo');
    //destinationprice and discount starts from
    const destinationPriceAndDiscount = document.createElement('div');
    destinationPriceAndDiscount.setAttribute('class', 'destinationPriceAndDiscount');
    destinationPriceAndDiscount.innerHTML = getSTartingPriceAndDiscount(eachSearchResultEntry, index);
    //no of days
    const noOfDays = document.createElement('div');
    noOfDays.setAttribute('class', 'noOfDays');
    noOfDays.innerHTML = `${eachSearchResultEntry.length} ${eachSearchResultEntry.length_type === 'd' ? '<span class="daysLabel">days</span>' : ''}`;
    //date and spaces left
    const dateAndSpaces = document.createElement('div');
    dateAndSpaces.setAttribute('class', 'dateAndSpaces');
    dateAndSpaces.innerHTML = getDatesAndVacentSpacesAvailable(eachSearchResultEntry, index)
    //view more button
    const viewMoreButton = document.createElement('div');
    viewMoreButton.setAttribute('class', 'viewMoreButton');
    const viewBtn = document.createElement('Button');
    viewBtn.setAttribute('class', 'btn');
    viewBtn.setAttribute('class', 'btn-success');
    viewBtn.textContent = 'View More'

    const leftSideDestinationInfo = document.createElement('div');
    leftSideDestinationInfo.setAttribute('class', 'leftSideDestinationInfo');
    const rightSideDestinationInfo = document.createElement('div');
    rightSideDestinationInfo.setAttribute('class', 'rightSideDestinationInfo');

    eachtripDestination.appendChild(rightDestinationInfo);
    rightDestinationInfo.appendChild(leftSideDestinationInfo);
    rightDestinationInfo.appendChild(rightSideDestinationInfo);
    leftSideDestinationInfo.appendChild(destinationPriceAndDiscount);
    leftSideDestinationInfo.appendChild(noOfDays);
    rightSideDestinationInfo.appendChild(dateAndSpaces);
    rightSideDestinationInfo != undefined && sortedStartingDates.length > 0 ? rightSideDestinationInfo.appendChild(viewMoreButton) : '';
    viewMoreButton.appendChild(viewBtn);
}